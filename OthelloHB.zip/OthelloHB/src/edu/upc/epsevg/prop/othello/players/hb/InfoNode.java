/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.upc.epsevg.prop.othello.players.hb;

/**
 *
 * @author Eric
 */
public class InfoNode {
    //Tal qual com a classe;
    byte indexMillorFill;
    long num1, num2;
    
    //public InfoNode(byte indexMillorFill, MyGameStatus myGameStatus) {
        //this.indexMillorFill = indexMillorFill;
        //this.num1 = myGameStatus.getBoard_occupied().toLongArray()[0];
        //this.num2 = myGameStatus.getBoard_color().toLongArray()[0];
    //}
}
